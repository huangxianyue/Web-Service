package com.huawei.rest.resources;

import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;


public class JerseyClient {
	
	public static void test(){
		Client client = Client.create();
		WebResource r = client.resource("http://localhost:8080/restDemo/rest/hello");
	/*	JSONObject obj = new JSONObject();  
        try {
			obj.put("a", "1");
			obj.put("b", "2");  
		} catch (JSONException e) {
			e.printStackTrace();
		}  */
        //JSONObject response = r.get(JSONObject.class);        
        String response = r.get(String.class);        
        System.out.println(response.toString());
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test();
	}

}
